// HelloWorld.java

/**
 * Application which displays a welcome message on standard output.
 */
public class HelloWorld
{

  //-------------------------------------------------------main()
  /**
   * The method that is called first when the application runs.
   */
  public static void main(String[] args)
  {
    //--- display the message on standard output
    System.out.println("Hello World!");

  } // end of main()  

} // end of class HelloWorld

